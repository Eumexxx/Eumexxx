#!/bin/bash

echo "Hello, $LOGNAME"
echo "Current date is `date`"
echo "User is `whoami`"
echo "Current directory `pwd`"
